# JOHALPLAY — how to build it on your Mac (~1 minute)

**You need (all free):**
- **Xcode 15 or newer** → Mac App Store
- **Your Apple ID** (the one on your iPhone — a free one works)
- **iPhone running iOS 17 or newer**, connected with its USB cable

---

## The 5 steps

**1.** Unzip `johalplay.zip`.

**2.** Double-click **`JohalPlay.xcodeproj`** to open it in Xcode.
*(If a window says the developer isn't verified, just press OK.)*

**3.** In Xcode's top toolbar, **pick your iPhone** as the target
(not "My Mac", not a simulator — your actual phone).

**4.** Left sidebar → click **JohalPlay** (the blue app icon at the top)
→ click the **Signing & Capabilities** tab
→ under **Team**, select **your Apple ID**.

> Not signed in yet? → Xcode menu → **Settings** → **Accounts** → **+**
> → add your Apple ID, then go back and pick it as the Team.

**5.** Plug in your iPhone (tap **Trust This Computer** on the phone)
→ press **⌘R** (or the ▶ Run button).

That's it — the app installs and opens on your iPhone. 🎉

---

## First launch

- Tap **+** → paste a YouTube link (or any MP4/HLS video link) → it plays
- Swipe left on a video to **rename**, swipe right to **delete**
- Rotate to **landscape** and mount the phone in the car
- Playback **auto-pauses when the car starts moving** — resume when parked
- Lock the screen and audio keeps playing

## CarPlay (if your car has it)

Connect your iPhone to the car (USB or wireless CarPlay) → JohalPlay
appears in the car with two tabs: **Videos** (your saved links) and
**Now Playing** (controls). The video itself plays on the phone screen —
Apple doesn't allow third-party video on the CarPlay display, that's a
platform rule, not a bug.

---

## If something goes wrong

| You see | Fix |
|---|---|
| "No Account for Team" | Step 4 — add your Apple ID in Xcode → Settings → Accounts |
| "Unable to run JohalPlay on My Mac" | Step 3 — pick your iPhone, not My Mac |
| "bundle id ... is already taken" (rare) | JohalPlay target → General → Identification → change the Bundle ID (add your name) |
| App stops working after 7 days | Free Apple ID certificates last 7 days — just press ⌘R again to refresh |
| **Any other red error** | **Copy the red error text and send it — it gets fixed in minutes** |
