#!/bin/zsh
# JohalPlay one-command build (run on a Mac with Xcode).
#
#   ./build.sh              -> build an unsigned .ipa for a real device
#   ./build.sh simulator    -> compile-only check against the iOS simulator
#
set -e
cd "$(dirname "$0")"

if [ "$1" = "simulator" ]; then
  echo ">> Compile check (simulator)..."
  xcodebuild -project JohalPlay.xcodeproj -scheme JohalPlay \
    -destination "generic/platform=iOS Simulator" build
  echo ">> Compile OK."
else
  echo ">> Archiving for iOS device (unsigned)..."
  rm -rf build
  xcodebuild -project JohalPlay.xcodeproj -scheme JohalPlay \
    -configuration Release -destination "generic/platform=iOS" \
    -archivePath build/JohalPlay.xcarchive \
    CODE_SIGNING_ALLOWED=NO archive
  APP_DIR="build/JohalPlay.xcarchive/Products/Applications"
  mkdir -p build/Payload
  mv "$APP_DIR/JohalPlay.app" build/Payload/
  ( cd build && zip -qry JohalPlay.ipa Payload )
  echo ""
  echo ">> Done: build/JohalPlay.ipa"
  echo ">> It is unsigned. Install it with AltStore/SideStore (re-signs with your"
  echo "   personal Apple ID), or open the project in Xcode, pick your Team in"
  echo "   Signing & Capabilities, and hit Run to get a signed build."
fi
