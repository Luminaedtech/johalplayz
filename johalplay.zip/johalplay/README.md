# JohalPlay — watch internet videos in your car 🚗

> **Just want it working on your phone today, no Mac, no building?**
> Open **`JohalPlay.html`** in iPhone Safari (WhatsApp/it to yourself, open with
> Safari, Share → *Add to Home Screen*). It's the same app in a single file:
> add YouTube/MP4/HLS links, big landscape player, auto-pause when the car
> moves. The only thing it can't do is appear on the CarPlay screen — that
> needs the native app below.

An iOS app for playing videos **from the internet** while you're in the car:
paste a link, tap, watch. Built around your car's screen — the car display
gets the full control surface via **CarPlay**, and the video itself plays on
your iPhone in a mount (landscape-locked, big buttons, auto-pause while driving).

## What you get

- **Add any video link** — YouTube links (`watch?v=`, `youtu.be`, `shorts`, `live`)
  or direct video links (MP4, HLS/`m3u8`, other progressive streams)
- **Saved library** — links persist on the phone, with rename (swipe left) and
  delete (swipe right). YouTube links auto-fetch their real title. Search bar
  included.
- **Resume where you left off** — watch progress is saved per video; rows show
  "Resume 12:34" with a progress bar, and playback picks up where you stopped
  (for both YouTube and direct streams).
- **Auto-play next** — when a video ends, the next one in your list starts
  automatically (toggle in the player's top bar, preference is remembered).
- **Car-optimized custom player** — big material top bar, auto-hiding bottom
  bar with scrubber + time + huge play button + 10s skips, tap the video to
  hide/show controls, haptic feedback, Picture-in-Picture button.
- **Two player engines, one control surface**
  - Direct links → native `AVPlayer` with the custom controls above + PiP
  - YouTube links → embedded player with the same big-button controls
- **CarPlay integration** — your car screen shows a **Videos** tab (all saved
  links, tap to start) and a **Now Playing** tab (title, time, −10s / play–pause / +10s)
- **Auto-pause while driving** — the motion sensor pauses playback when the car
  starts moving (safer *and* saves mobile data). You can resume when parked.
- **Background audio** — lock the phone screen and audio keeps playing;
  CarPlay keeps full control. Direct streams also support PiP.

## The one platform rule you should know

Apple does **not** provide any public API for third-party iOS apps to render
video on the CarPlay display (only Apple's own apps can, and only while the car
is stopped). So JohalPlay uses the only compliant architecture:

| Screen | Shows |
|---|---|
| Car screen (CarPlay) | Video list + Now Playing controls |
| iPhone (in dash mount) | The actual video, landscape, big touch controls |

This is a platform limitation, not a missing feature — no App Store app can
bypass it (apps that claim to are jailbreak tools). If your car runs
**Android Auto** (common on Indian cars) with an iPhone, the car's Media
integration is audio-only — the phone in the mount is your video screen, which
is exactly what JohalPlay optimizes for.

DRM-protected services (Netflix, Hotstar, Prime, etc.) cannot be played in-app
or on CarPlay — those are their own apps' turf.

## Requirements

- macOS with **Xcode 15+**
- An iPhone running **iOS 17+**
- Internet (Wi-Fi or cellular)
- For the car-screen UI: a car/head-unit with **CarPlay**

## Build & run

### Option A — Mac with Xcode (fastest, ~30 seconds)

1. Open `JohalPlay.xcodeproj` in Xcode.
2. Select the **JohalPlay** target → *Signing & Capabilities* → choose your
   **Team** (a free Apple ID works for installing on your own phone).
3. Plug in your iPhone, trust the computer, select it in the toolbar, press **⌘R**.
4. First launch: tap **+**, paste a link (try a YouTube link and an MP4 link),
   and watch.
5. Rotate to landscape, mount the phone, and drive (with a passenger watching —
   or when parked 😉).
6. **CarPlay:** connect the iPhone to the car (USB or wireless CarPlay).
   JohalPlay appears with the Videos and Now Playing tabs.

> The bundle id defaults to `com.example.johalplay` — change it under
> target → *General* → *Identification* if you like.

### Option B — no Mac: one command or GitHub Actions

- **One command** (on any Mac): `./build.sh` → produces `build/JohalPlay.ipa`
  (unsigned). `./build.sh simulator` is a compile-only check.
- **GitHub Actions** (no Mac at all): push this folder to a GitHub repo —
  the workflow in `.github/workflows/build-ipa.yml` builds a `.ipa` on
  Apple's macOS runners on every push. Download it from *Actions →
  workflow run → artifacts*.
- **Installing an unsigned ipa:** use **AltStore** or **SideStore** with your
  personal (free) Apple ID — they re-sign the app for your device
  (AltStore refreshes it every 7 days). This is the standard personal
  sideloading path.

## How the CarPlay tabs work

- **Videos** — every saved link. Tap one and it starts playing on the phone;
  the car screen jumps to Now Playing.
- **Now Playing** — title, `elapsed / total` time, and transport buttons
  (−10s, play/pause, +10s) that work for both YouTube and direct streams.
- With the phone screen off: audio continues and CarPlay stays in control.

## Safety & data

- Motion detection (CoreMotion) auto-pauses when the car moves. "Resume
  anyway" is your call — and it costs you data too.
- Watching video while driving is dangerous and is prohibited under Indian
  road law (Motor Vehicles Act / CMVR distracted-driving provisions). JohalPlay
  is meant for passengers, or for the driver while parked.
- Motion detection is a heuristic (on-device accelerometer); it is inactive in
  the simulator, so test the auto-pause on a real device.

## Project layout

```
johalplay/
├── JohalPlay.xcodeproj
└── JohalPlay/
    ├── JohalPlayApp.swift          # App entry, root routing (library → player)
    ├── StreamLibrary.swift        # Saved links, YouTube link parsing, oEmbed titles
    ├── PlayerManager.swift        # One playback brain for direct + YouTube
    ├── YouTubeBridge.swift        # Off-screen WKWebView driving the YT IFrame API
    ├── MotionMonitor.swift        # Car-motion detection (auto-pause)
    ├── LibraryView.swift          # Saved links list, add/rename sheets
    ├── PlayerView.swift           # Full-screen player, big buttons, motion card
    ├── CarPlaySceneDelegate.swift # CarPlay scene: Videos + Now Playing tabs
    ├── Info.plist                 # CarPlay scene manifest, background audio, landscape
    └── Assets.xcassets
```

## Troubleshooting

- **"No Account for Team" / signing error in Xcode** — target →
  *Signing & Capabilities* → pick a Team (your personal Apple ID). You must be
  signed into Xcode first: *Xcode → Settings → Accounts*.
- **"Unable to run JohalPlay on My Mac — built for iOS"** — this app is
  iOS-only. Pick an iPhone simulator or a connected iPhone as the run target.
- **Code compiles but CarPlay tab not appearing** — check target → *General* → *Deployment
  Info* → tick **Supports CarPlay**, then re-run. CarPlay needs a real
  car/head-unit (or a CarPlay dongle) to show up.
- **A direct link won't play** — some sites block non-browser players or use
  DRM; MP4/HLS file URLs work best. The app allows plain-HTTP streams
  (ATS is relaxed in `Info.plist`) for local/NAS-style sources.
- **YouTube link added but won't play** — YouTube occasionally restricts
  embeds for certain videos (channels can disable embedding).
- **Motion auto-pause feels too sensitive** — tune the threshold in
  `MotionMonitor.swift` (0.35 magnitude / 3 samples ≈ 1.5 s).

## Roadmap ideas

- YouTube search inside the app (passenger picks, driver drives)
- Playlists + resume-where-you-left-off
- AirPlay casting to head-units that support it
- GPS speed lock (hard-block video below/above a speed)
