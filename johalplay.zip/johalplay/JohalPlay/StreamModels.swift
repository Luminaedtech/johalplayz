import Foundation

/// Where a stream comes from.
enum StreamKind: String, Codable {
    case direct
    case youtube
}

/// One saved internet video link.
struct StreamItem: Identifiable, Codable, Equatable {
    var id: UUID
    var name: String
    var url: URL
    var kind: StreamKind
    var addedDate: Date
    var duration: Double? = nil
    var lastPosition: Double? = nil

    /// The YouTube video id, when kind == .youtube
    var youtubeID: String? {
        guard kind == .youtube else { return nil }
        return YouTubeLinkParser.videoID(from: url)
    }

    /// True when there's a saved spot worth resuming from.
    var resumePosition: Double? {
        guard let position = lastPosition, position > 10 else { return nil }
        if let duration, duration > 0, position >= duration - 10 { return nil }
        return position
    }
}

/// Extracts a YouTube video id from the common URL shapes
/// (watch?v=, youtu.be/, shorts/, embed/, live/).
enum YouTubeLinkParser {
    static func videoID(from url: URL) -> String? {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let host = (components?.host ?? "").lowercased()
        let isYouTubeHost = host == "youtube.com"
            || host.hasSuffix(".youtube.com")
            || host == "youtu.be"
            || host == "youtube-nocookie.com"
        guard isYouTubeHost else { return nil }

        if let queryID = components?.queryItems?.first(where: { $0.name == "v" })?.value,
           isValidID(queryID) {
            return queryID
        }

        let segments = (components?.path ?? "").split(separator: "/").map(String.init)
        for prefix in ["shorts", "embed", "live", "v"] where segments.count > 1 && segments[0] == prefix {
            if isValidID(segments[1]) {
                return segments[1]
            }
        }

        if host == "youtu.be", segments.count == 1, isValidID(segments[0]) {
            return segments[0]
        }
        return nil
    }

    private static func isValidID(_ candidate: String) -> Bool {
        candidate.count == 11
            && candidate.allSatisfy { $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" }
    }
}
