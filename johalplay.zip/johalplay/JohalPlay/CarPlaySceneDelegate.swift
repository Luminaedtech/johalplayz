import AVFoundation
import CarPlay
import UIKit

/// The CarPlay scene delegate.
///
/// Apple does not let third-party apps render video on the CarPlay
/// display, so the car screen hosts the control surface (video list,
/// now playing, transport controls) while the video itself plays on
/// the iPhone — full-screen, or as audio + Picture in Picture when
/// the phone screen is off.
final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {

    private var session: CPApplicationSession?
    private var tabTemplate: CPTabTemplate?
    private var nowPlayingController: CarPlayNowPlayingController?
    private var refreshTimer: Timer?

    // MARK: - CPTemplateApplicationSceneDelegate

    func carplayService(_ carplayService: CPService, willConnectWithSession session: CPApplicationSession) -> Bool {
        self.session = session
        Task { @MainActor in
            self.buildCarPlayUI(for: session)
        }
        return true
    }

    func carplayService(_ carplayService: CPService, didDisconnectWithSession session: CPApplicationSession) {
        refreshTimer?.invalidate()
        refreshTimer = nil
        tabTemplate = nil
        nowPlayingController = nil
        self.session = nil
    }

    // MARK: - Setup

    @MainActor
    private func buildCarPlayUI(for session: CPApplicationSession) {
        let videosTab = CPTab(title: "Videos", image: UIImage(systemName: "film"), role: .primary)
        let nowPlayingTab = CPTab(title: "Now Playing", image: UIImage(systemName: "play.circle"), role: .secondary)

        let template = CPTabTemplate(tabs: [videosTab, nowPlayingTab])

        let videosController = CarPlayVideosController()
        videosController.onVideoSelected = { [weak self] in
            self?.selectTab(nowPlayingTab)
        }
        let nowPlayingController = CarPlayNowPlayingController()

        template.tabSectionController(for: videosTab) = videosController
        template.tabSectionController(for: nowPlayingTab) = nowPlayingController

        self.tabTemplate = template
        self.nowPlayingController = nowPlayingController

        session.setRootTemplate(template, animated: true)

        refreshTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.refreshNowPlaying()
            }
        }
    }

    @MainActor
    private func selectTab(_ tab: CPTab) {
        tabTemplate?.selectTab(tab, animated: true)
    }

    @MainActor
    private func refreshNowPlaying() {
        nowPlayingController?.refresh()
    }
}

// MARK: - Videos tab

/// Lists the saved internet video links on CarPlay.
final class CarPlayVideosController: CPListSectionController {

    var onVideoSelected: (@MainActor () -> Void)?

    override func loadSection(_ section: CPListSection) {
        section.removeAllItems()

        Task { @MainActor in
            let library = StreamLibrary.shared
            if library.items.isEmpty {
                let empty = CarPlayVideoListItem(
                    title: "No videos yet",
                    detail: "Add links in the iPhone app",
                    onSelect: {}
                )
                section.appendItem(empty)
                return
            }
            for item in library.items {
                let host = item.url.host?.replacingOccurrences(of: "www.", with: "") ?? "video"
                let row = CarPlayVideoListItem(
                    title: item.name,
                    detail: host,
                    onSelect: { [weak self] in
                        PlayerManager.shared.load(item, autoplay: true)
                        self?.onVideoSelected?()
                    }
                )
                section.appendItem(row)
            }
        }
    }
}

// MARK: - Now Playing tab

final class CarPlayNowPlayingController: CPSectionController {

    private var template: CarPlayNowPlayingTemplate?

    override func loadSection(_ section: CPListSection) {
        section.removeAllItems()
        let template = CarPlayNowPlayingTemplate()
        template.tabTemplate = tabTemplate
        template.loadSection(section)
        self.template = template
    }

    func refresh() {
        template?.refresh()
    }
}

/// Custom "Now Playing" template: artwork placeholder, title,
/// elapsed/total time and transport buttons. Works for both direct
/// streams and YouTube embeds (state comes from PlayerManager).
final class CarPlayNowPlayingTemplate: CPTemplate {

    private var artworkView: UIImageView?
    private var titleLabel: UILabel?
    private var subtitleLabel: UILabel?
    private var playButton: CPButton?

    override func buildTemplate(with size: CGSize) -> UIView {
        let container = UIView(frame: CGRect(origin: .zero, size: size))

        let artwork = UIImageView()
        artwork.contentMode = .center
        artwork.backgroundColor = UIColor(white: 0.08, alpha: 1)
        artwork.image = UIImage(systemName: "film")
        artwork.tintColor = UIColor(white: 0.4, alpha: 1)
        let side = min(size.width, size.height) * 0.62
        artwork.frame = CGRect(x: (size.width - side) / 2, y: size.height * 0.05, width: side, height: side)

        let title = UILabel()
        title.font = UIFont.systemFont(ofSize: 30, weight: .semibold)
        title.textColor = .white
        title.textAlignment = .center
        title.numberOfLines = 2
        title.frame = CGRect(x: 24, y: artwork.frame.maxY + 18, width: size.width - 48, height: 44)

        let subtitle = UILabel()
        subtitle.font = UIFont.systemFont(ofSize: 22, weight: .regular)
        subtitle.textColor = UIColor.white.withAlphaComponent(0.7)
        subtitle.textAlignment = .center
        subtitle.frame = CGRect(x: 24, y: title.frame.maxY + 4, width: size.width - 48, height: 30)

        let back = CPButton(title: "", image: UIImage(systemName: "gobackward.10")) {
            PlayerManager.shared.seekBy(-10)
        }
        let play = CPButton(title: "", image: UIImage(systemName: "play.circle.fill")) {
            PlayerManager.shared.togglePlayback()
        }
        let forward = CPButton(title: "", image: UIImage(systemName: "goforward.10")) {
            PlayerManager.shared.seekBy(10)
        }
        play.imageSize = CGSize(width: 84, height: 84)
        back.imageSize = CGSize(width: 52, height: 52)
        forward.imageSize = CGSize(width: 52, height: 52)

        let buttonCenterY = size.height - 110
        back.frame = CGRect(x: size.width / 2 - 220, y: buttonCenterY - 40, width: 80, height: 80)
        play.frame = CGRect(x: size.width / 2 - 50, y: buttonCenterY - 50, width: 100, height: 100)
        forward.frame = CGRect(x: size.width / 2 + 140, y: buttonCenterY - 40, width: 80, height: 80)

        container.addSubview(artwork)
        container.addSubview(title)
        container.addSubview(subtitle)
        container.addSubview(back)
        container.addSubview(play)
        container.addSubview(forward)

        artworkView = artwork
        titleLabel = title
        subtitleLabel = subtitle
        playButton = play

        refresh()
        return container
    }

    /// Updates labels from shared player state. Called about once
    /// per second by the CarPlay scene delegate.
    func refresh() {
        Task { @MainActor in
            let manager = PlayerManager.shared
            if let video = manager.currentVideo {
                self.titleLabel?.text = video.name
                let current = Int(manager.currentTime)
                let total = Int(manager.duration)
                self.subtitleLabel?.text = String(format: "%d:%02d  /  %d:%02d", current / 60, current % 60, total / 60, total % 60)
                if video.kind == .youtube {
                    self.artworkView?.image = UIImage(systemName: "play.rectangle.fill")
                    self.artworkView?.tintColor = .systemRed
                } else {
                    self.artworkView?.image = UIImage(systemName: "video.fill")
                    self.artworkView?.tintColor = UIColor(white: 0.6, alpha: 1)
                }
            } else {
                self.titleLabel?.text = "Nothing playing"
                self.subtitleLabel?.text = "Pick a video from the Videos tab"
                self.artworkView?.image = UIImage(systemName: "film")
                self.artworkView?.tintColor = UIColor(white: 0.4, alpha: 1)
            }
            self.playButton?.setImage(
                UIImage(systemName: manager.isPlaying ? "pause.circle.fill" : "play.circle.fill"),
                for: .normal
            )
        }
    }
}

// MARK: - List item

final class CarPlayVideoListItem: CPListItem {

    private let onSelect: @MainActor () -> Void

    init(title: String, detail: String, onSelect: @escaping @MainActor () -> Void) {
        self.onSelect = onSelect
        super.init(text1: title, image: nil, detail1: detail, accessoryType: .none)
    }

    override func didSelectItem() {
        let action = onSelect
        Task { @MainActor in
            action()
        }
    }
}
