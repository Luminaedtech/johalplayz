import Foundation

/// The persisted list of internet video links.
final class StreamLibrary: ObservableObject {

    static let shared = StreamLibrary()

    @Published private(set) var items: [StreamItem] = []
    @Published var addErrorMessage: String?

    private let metadataURL: URL = {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return dir.appendingPathComponent("stream-library.json")
    }()

    private init() {
        loadFromDisk()
    }

    func loadFromDisk() {
        guard let data = try? Data(contentsOf: metadataURL),
              let decoded = try? JSONDecoder().decode([StreamItem].self, from: data) else {
            items = []
            return
        }
        items = decoded.sorted { $0.addedDate > $1.addedDate }
    }

    private func saveToDisk() {
        if let data = try? JSONEncoder().encode(items) {
            try? data.write(to: metadataURL, options: .atomic)
        }
    }

    // MARK: - Adding / editing

    /// Parses a user-supplied link and adds it to the library.
    /// Returns the created item, or nil on failure (message in addErrorMessage).
    @discardableResult
    func add(urlString: String) async -> StreamItem? {
        let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            await MainActor.run { self.addErrorMessage = "Paste a link first." }
            return nil
        }

        var candidate = trimmed
        if !candidate.lowercased().hasPrefix("http://") && !candidate.lowercased().hasPrefix("https://") {
            candidate = "https://" + candidate
        }
        guard let url = URL(string: candidate),
              let scheme = url.scheme?.lowercased(),
              scheme == "http" || scheme == "https" else {
            await MainActor.run { self.addErrorMessage = "That doesn't look like a valid link." }
            return nil
        }

        let videoID = YouTubeLinkParser.videoID(from: url)
        var name: String
        if let videoID {
            name = (try? await fetchYouTubeTitle(videoID: videoID)) ?? "YouTube video"
        } else {
            name = friendlyName(for: url)
        }

        let item = StreamItem(
            id: UUID(),
            name: name,
            url: url,
            kind: videoID == nil ? .direct : .youtube,
            addedDate: Date()
        )
        await MainActor.run {
            self.items.insert(item, at: 0)
            self.saveToDisk()
        }
        return item
    }

    func remove(_ item: StreamItem) {
        items.removeAll { $0.id == item.id }
        saveToDisk()
    }

    func rename(_ item: StreamItem, to newName: String) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].name = newName.trimmingCharacters(in: .whitespaces)
        saveToDisk()
    }

    // MARK: - Watch progress

    /// Updates saved position (and duration, when learned) for a video.
    /// Called periodically by the PlayerManager — must be on the main thread.
    func updateProgress(for itemID: UUID, position: Double, duration: Double?) {
        guard let index = items.firstIndex(where: { $0.id == itemID }) else { return }
        var changed = false
        if let duration, duration > 0, abs((items[index].duration ?? 0) - duration) > 1 {
            items[index].duration = duration
            changed = true
        }
        if position > 10 {
            let old = items[index].lastPosition ?? 0
            if abs(position - old) >= 5 {
                items[index].lastPosition = position
                changed = true
            }
        }
        if changed {
            saveToDisk()
        }
    }

    /// Clears the saved position so the video starts fresh next time.
    func markFinished(_ itemID: UUID) {
        guard let index = items.firstIndex(where: { $0.id == itemID }),
              (items[index].lastPosition ?? 0) > 0 else { return }
        items[index].lastPosition = 0
        saveToDisk()
    }

    /// The video that plays after `current` (wraps around to the first).
    func next(after current: StreamItem) -> StreamItem? {
        guard items.count > 1 else { return nil }
        guard let index = items.firstIndex(where: { $0.id == current.id }) else {
            return items.first
        }
        return items[(index + 1) % items.count]
    }

    // MARK: - Naming

    private func friendlyName(for url: URL) -> String {
        guard let host = url.host?.replacingOccurrences(of: "www.", with: "") else {
            return url.absoluteString
        }
        if url.path.count > 1 {
            let last = url.path.split(separator: "/").last.map { String($0).removingPercentEncoding ?? String($0) }
            if let last, !last.isEmpty {
                return "\(host) • \(last)"
            }
        }
        return host
    }

    /// Fetches a human-friendly title for a YouTube link via oEmbed.
    private func fetchYouTubeTitle(videoID: String) async throws -> String {
        var components = URLComponents(string: "https://www.youtube.com/oembed")!
        components.queryItems = [
            URLQueryItem(name: "url", value: "https://www.youtube.com/watch?v=\(videoID)"),
            URLQueryItem(name: "format", value: "json")
        ]
        guard let oembedURL = components.url else { return "YouTube video" }
        let (data, _) = try await URLSession.shared.data(from: oembedURL)
        struct OEmbed: Decodable { let title: String }
        return try JSONDecoder().decode(OEmbed.self, from: data).title
    }
}
