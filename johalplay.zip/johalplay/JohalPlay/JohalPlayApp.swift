import SwiftUI

@main
struct JohalPlayApp: App {
    @StateObject private var player = PlayerManager.shared
    @StateObject private var library = StreamLibrary.shared
    @StateObject private var motion = MotionMonitor()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(player)
                .environmentObject(library)
                .environmentObject(motion)
                .preferredColorScheme(.dark)
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var player: PlayerManager

    var body: some View {
        NavigationStack {
            LibraryView()
        }
        .fullScreenCover(item: currentVideo) { video in
            PlayerView(video: video)
        }
    }

    private var currentVideo: Binding<StreamItem?> {
        Binding(
            get: { player.currentVideo },
            set: { player.currentVideo = $0 }
        )
    }
}
