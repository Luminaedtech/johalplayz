import Foundation
import WebKit

/// Drives a YouTube IFrame embed inside an (optionally off-screen)
/// WKWebView, so the same transport controls work for YouTube links
/// and for direct video streams. The web view can keep running in
/// the background so audio continues while the phone screen is off.
final class YouTubeBridge: NSObject, WKScriptMessageHandler {

    struct Callbacks {
        var onStateChanged: (_ isPlaying: Bool, _ isEnded: Bool) -> Void
        var onTime: (_ current: Double, _ duration: Double) -> Void
    }

    /// A position to seek to as soon as the embedded player is ready
    /// (used for "resume where you left off").
    var pendingSeek: Double?

    private(set) lazy var webView: WKWebView = {
        let configuration = WKWebViewConfiguration()
        let contentController = WKUserContentController()
        contentController.add(self, name: "dash")
        configuration.userContentController = contentController

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = true
        webView.backgroundColor = .black
        webView.customUserAgent = "JohalPlay/1.0"
        webView.allowsInlineMediaPlayback = true
        webView.mediaTypesRequiringUserActionForPlayback = []
        return webView
    }()

    var callbacks: Callbacks?

    private(set) var isLoaded = false

    func load(videoID: String, autoplay: Bool) {
        isLoaded = false
        webView.loadHTMLString(Self.makeHTML(videoID: videoID, autoplay: autoplay), baseURL: nil)
    }

    // MARK: - Transport controls (run as JavaScript)

    func play() {
        runJS("player && player.playVideo();")
    }

    func pause() {
        runJS("player && player.pauseVideo();")
    }

    func seekBy(_ seconds: Double) {
        runJS("player && player.seekTo(player.getCurrentTime() + \(seconds), true);")
    }

    func runJS(_ script: String) {
        webView.evaluateJavaScript(script) { _, _ in }
    }

    // MARK: - WKScriptMessageHandler

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard message.name == "dash", let body = message.body as? String else { return }
        let data = body.data(using: .utf8) ?? Data()
        guard let payload = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let event = payload["event"] as? String else { return }

        let state = payload["state"] as? Int ?? -1
        let time = payload["time"] as? Double ?? 0
        let duration = payload["duration"] as? Double ?? 0

        switch event {
        case "ready":
            isLoaded = true
            callbacks?.onStateChanged(isPlaying: state == 2, isEnded: false)
            callbacks?.onTime(time, duration)
            if let seek = pendingSeek {
                pendingSeek = nil
                runJS("player && player.seekTo(\(seek), true);")
            }
        case "state":
            callbacks?.onStateChanged(isPlaying: state == 2, isEnded: state == 0)
        case "tick":
            callbacks?.onTime(time, duration)
        default:
            break
        }
    }

    // MARK: - HTML

    static func makeHTML(videoID: String, autoplay: Bool) -> String {
        """
        <!DOCTYPE html>
        <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
          <style>html,body{margin:0;padding:0;background:#000;width:100%;height:100%;overflow:hidden}#player{position:absolute;top:0;left:0;right:0;bottom:0}</style>
        </head>
        <body>
          <div id="player"></div>
          <script src="https://www.youtube.com/iframe_api"></script>
          <script>
            var player;
            function send(o) {
              try {
                if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.dash) {
                  window.webkit.messageHandlers.dash.postMessage(JSON.stringify(o));
                }
              } catch (e) {}
            }
            function onYouTubeIframeAPIReady() {
              player = new YT.Player('player', {
                width: '100%',
                height: '100%',
                videoId: '\(videoID)',
                playerVars: { autoplay: \(autoplay ? 1 : 0), controls: 1, rel: 0, playsinline: 1, iv_load_policy: 3 },
                events: {
                  onReady: function () {
                    send({ event: 'ready', state: player.getPlayerState(), time: player.getCurrentTime() || 0, duration: player.getDuration() || 0 });
                    setInterval(function () {
                      try {
                        send({ event: 'tick', state: player.getPlayerState(), time: player.getCurrentTime() || 0, duration: player.getDuration() || 0 });
                      } catch (e) {}
                    }, 1000);
                  },
                  onStateChange: function (e) {
                    send({ event: 'state', state: e.data });
                  },
                  onError: function (e) {
                    send({ event: 'state', state: 0 });
                  }
                }
              });
            }
          </script>
        </body>
        </html>
        """
    }
}
