import CoreMotion
import Foundation
import SwiftUI

/// Detects whether the device appears to be in a moving vehicle
/// using the device-motion sensor. Heuristic: sustained acceleration
/// above a threshold for roughly 1.5 seconds.
final class MotionMonitor: ObservableObject {

    @Published private(set) var isMoving = false

    private let motionManager = CMMotionManager()
    private var motionSamples = 0

    init() {
        guard motionManager.isDeviceMotionAvailable else { return }
        motionManager.deviceMotionUpdateInterval = 0.5
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] motion, _ in
            guard let self, let motion else { return }
            guard let acceleration = motion.userAccelerometerData?.acceleration else { return }
            let magnitude = abs(acceleration.x) + abs(acceleration.y) + abs(acceleration.z)
            if magnitude > 0.35 {
                self.motionSamples += 1
            } else {
                self.motionSamples = max(0, self.motionSamples - 1)
            }
            self.isMoving = self.motionSamples >= 3
        }
    }
}
