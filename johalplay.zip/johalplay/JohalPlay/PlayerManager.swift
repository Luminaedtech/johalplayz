import AVFoundation
import Foundation

/// Owns playback for both direct streams (AVPlayer) and YouTube
/// embeds (YouTubeBridge) so the phone UI and the CarPlay scene
/// share one control surface.
final class PlayerManager: ObservableObject {

    static let shared = PlayerManager()

    @Published var currentVideo: StreamItem?
    @Published var isPlaying = false
    @Published var currentTime: Double = 0
    @Published var duration: Double = 0
    @Published var autoNext = true

    let avPlayer = AVPlayer()
    let youtube = YouTubeBridge()

    private var timeObserver: Any?
    private var statusObservation: NSKeyValueObservation?
    private var endObserver: NSObjectProtocol?
    private var pipController: AVPlayerPictureInPictureController?
    private var lastProgressSave = Date.distantPast

    init() {
        autoNext = UserDefaults.standard.object(forKey: "autoNext") as? Bool ?? true

        timeObserver = avPlayer.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.5, preferredTimescale: 600),
            queue: .main
        ) { [weak self] time in
            guard let self, self.currentVideo?.kind == .direct else { return }
            self.currentTime = time.seconds
            self.saveProgressIfNeeded(position: time.seconds)
        }

        statusObservation = avPlayer.observe(\.timeControlStatus, options: [.new]) { [weak self] observedPlayer, _ in
            DispatchQueue.main.async {
                guard let self, self.currentVideo?.kind == .direct else { return }
                self.isPlaying = (observedPlayer.timeControlStatus == .playing)
            }
        }

        endObserver = NotificationCenter.default.addObserver(
            forName: AVPlayerItem.didPlayToEndTimeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            DispatchQueue.main.async {
                guard let self, self.currentVideo?.kind == .direct else { return }
                self.handleEnded()
            }
        }

        youtube.callbacks = YouTubeBridge.Callbacks(
            onStateChanged: { [weak self] playing, ended in
                DispatchQueue.main.async {
                    guard let self, self.currentVideo?.kind == .youtube else { return }
                    self.isPlaying = playing
                    if ended {
                        self.handleEnded()
                    }
                }
            },
            onTime: { [weak self] current, duration in
                DispatchQueue.main.async {
                    guard let self, self.currentVideo?.kind == .youtube else { return }
                    self.currentTime = current
                    if duration > 0 {
                        self.duration = duration
                    }
                    self.saveProgressIfNeeded(
                        position: current,
                        knownDuration: duration > 0 ? duration : nil
                    )
                }
            }
        )
    }

    deinit {
        if let timeObserver {
            avPlayer.removeTimeObserver(timeObserver)
        }
        statusObservation?.invalidate()
        if let endObserver {
            NotificationCenter.default.removeObserver(endObserver)
        }
    }

    // MARK: - Playback

    func load(_ video: StreamItem, autoplay: Bool = true) {
        if currentVideo?.id == video.id {
            if autoplay { play() }
            return
        }
        currentVideo = video
        currentTime = video.resumePosition ?? 0
        duration = video.duration ?? 0
        lastProgressSave = Date()
        configureAudioSession()

        switch video.kind {
        case .direct:
            let item = AVPlayerItem(url: video.url)
            avPlayer.replaceCurrentItem(with: item)
            ensurePiPController()
            resumePositionIfNeeded()
            Task { @MainActor [weak self] in
                let assetDuration = (try? await item.asset.load(.duration))?.seconds ?? 0
                if assetDuration > 0 {
                    self?.duration = assetDuration
                }
            }
            if autoplay {
                avPlayer.play()
            }
        case .youtube:
            youtube.pendingSeek = video.resumePosition
            if let videoID = video.youtubeID {
                youtube.load(videoID: videoID, autoplay: autoplay)
            }
        }
    }

    func play() {
        configureAudioSession()
        switch currentVideo?.kind {
        case .direct, nil:
            avPlayer.play()
        case .youtube:
            youtube.play()
        }
    }

    func pause() {
        switch currentVideo?.kind {
        case .direct, nil:
            avPlayer.pause()
        case .youtube:
            youtube.pause()
        }
    }

    func togglePlayback() {
        if isPlaying {
            pause()
        } else {
            play()
        }
    }

    func seekBy(_ seconds: Double) {
        seek(to: currentTime + seconds)
    }

    func seek(to seconds: Double) {
        switch currentVideo?.kind {
        case .direct, nil:
            let clamped = max(0, min(duration, seconds))
            let target = CMTime(seconds: clamped, preferredTimescale: 600)
            avPlayer.seek(to: target, toleranceBefore: .zero, toleranceAfter: .zero)
        case .youtube:
            let clamped = max(0, seconds)
            youtube.runJS("player && player.seekTo(\(clamped), true);")
        }
    }

    // MARK: - Picture in Picture (direct streams)

    private func ensurePiPController() {
        guard pipController == nil else { return }
        let configuration = AVPlayerPictureInPictureConfiguration()
        pipController = AVPlayerPictureInPictureController(
            player: avPlayer,
            activePictureInPictureConfiguration: configuration
        )
    }

    var canPictureInPicture: Bool {
        pipController?.canStartPictureInPicture ?? false
    }

    var isPiPActive: Bool {
        pipController?.isPictureInPictureActive ?? false
    }

    func togglePictureInPicture() {
        guard currentVideo?.kind == .direct, let pip = pipController else { return }
        if pip.isPictureInPictureActive {
            pip.stopPictureInPicture()
        } else if pip.canStartPictureInPicture {
            pip.startPictureInPicture()
        }
    }

    // MARK: - Auto-next

    func setAutoNext(_ on: Bool) {
        autoNext = on
        UserDefaults.standard.set(on, forKey: "autoNext")
    }

    private func handleEnded() {
        guard let video = currentVideo else { return }
        StreamLibrary.shared.markFinished(video.id)
        if autoNext, let next = StreamLibrary.shared.next(after: video) {
            load(next, autoplay: true)
        } else {
            closePlayback()
        }
    }

    private func closePlayback() {
        currentVideo = nil
        isPlaying = false
        currentTime = 0
        duration = 0
    }

    // MARK: - Watch progress

    private func resumePositionIfNeeded() {
        guard let position = currentVideo?.resumePosition else { return }
        let target = CMTime(seconds: position, preferredTimescale: 600)
        avPlayer.seek(to: target, toleranceBefore: .zero, toleranceAfter: .zero)
    }

    private func saveProgressIfNeeded(position: Double, knownDuration: Double? = nil) {
        guard let video = currentVideo else { return }
        let now = Date()
        guard now.timeIntervalSince(lastProgressSave) >= 5 else { return }
        lastProgressSave = now
        let learnedDuration = knownDuration ?? (duration > 0 ? duration : nil)
        StreamLibrary.shared.updateProgress(
            for: video.id,
            position: position,
            duration: learnedDuration
        )
    }

    // MARK: - Audio session

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(
                .playback,
                mode: .moviePlayback,
                options: [.mixWithOthers, .pictureInPicture]
            )
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("JohalPlay audio session error: \(error.localizedDescription)")
        }
    }
}
