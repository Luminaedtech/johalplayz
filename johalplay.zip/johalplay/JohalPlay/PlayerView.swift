import AVKit
import SwiftUI
import WebKit

struct PlayerView: View {
    let video: StreamItem

    @EnvironmentObject private var player: PlayerManager
    @EnvironmentObject private var motion: MotionMonitor
    @Environment(\.dismiss) private var dismiss

    @State private var controlsVisible = true
    @State private var pausedByMotion = false
    @State private var scrubbing = false
    @State private var scrubValue: Double = 0
    @State private var hideTask: Task<Void, Never>?

    var body: some View {
        ZStack(alignment: .top) {
            surface
                .ignoresSafeArea()

            if video.kind == .direct && controlsVisible {
                bottomControls
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    .transition(.opacity)
            }
        }
        .overlay(alignment: .top) {
            topBar
        }
        .overlay {
            if pausedByMotion {
                motionPausedCard
            }
        }
        .statusBarHidden(true)
        .onAppear {
            if player.currentVideo?.id != video.id {
                player.load(video, autoplay: true)
            } else {
                player.play()
            }
            UIApplication.shared.isIdleTimerDisabled = true
            scheduleControlsHide()
        }
        .onChange(of: video.id) { _, newID in
            if player.currentVideo?.id != newID {
                player.load(video, autoplay: true)
            } else {
                player.play()
            }
            scheduleControlsHide()
        }
        .onChange(of: player.isPlaying) { _, playing in
            if playing {
                scheduleControlsHide()
            } else {
                withAnimation(.easeOut(duration: 0.2)) {
                    controlsVisible = true
                }
            }
        }
        .onChange(of: motion.isMoving) { _, isMovingNow in
            if isMovingNow && player.isPlaying && !pausedByMotion {
                player.pause()
                pausedByMotion = true
            }
        }
        .onDisappear {
            player.pause()
            hideTask?.cancel()
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }

    // MARK: - Surface

    @ViewBuilder
    private var surface: some View {
        if video.kind == .direct {
            JohalAVPlayer(player: player.avPlayer)
                .contentShape(Rectangle())
                .onTapGesture {
                    if controlsVisible {
                        hideControls()
                    } else {
                        showControls()
                    }
                }
        } else {
            YouTubeSurface(webView: player.youtube.webView)
        }
    }

    // MARK: - Top bar

    private var topBar: some View {
        HStack(spacing: 12) {
            Button {
                hideTask?.cancel()
                dismiss()
            } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(.ultraThinMaterial, in: Circle())
            }

            VStack(alignment: .leading, spacing: 1) {
                Text(video.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(video.kind == .youtube ? "YouTube" : "Direct stream")
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.6))
            }
            .padding(.leading, 2)

            Spacer()

            Button {
                player.setAutoNext(!player.autoNext)
            } label: {
                Image(systemName: player.autoNext ? "arrow.right.to.line.alt.fill" : "arrow.right.to.line.alt")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundStyle(player.autoNext ? Color.orange : .white.opacity(0.7))
                    .frame(width: 44, height: 44)
                    .background(.ultraThinMaterial, in: Circle())
            }
            .accessibilityLabel("Auto-play next")
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                colors: [.black.opacity(0.65), .clear],
                startPoint: .top,
                endPoint: .bottom
            )
        )
    }

    // MARK: - Bottom controls (direct streams)

    private var bottomControls: some View {
        VStack(spacing: 8) {
            HStack(spacing: 12) {
                Text(timeText(player.currentTime))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.white.opacity(0.85))
                Slider(
                    value: Binding(
                        get: { scrubbing ? scrubValue : player.currentTime },
                        set: { scrubValue = $0 }
                    ),
                    in: 0...max(player.duration, 1),
                    onEditingChanged: { editing in
                        scrubbing = editing
                        if !editing {
                            player.seek(to: scrubValue)
                            scrubbing = false
                        }
                    }
                )
                .tint(.orange)
                Text(timeText(player.duration))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.white.opacity(0.85))
            }

            HStack(spacing: 36) {
                Button {
                    player.seekBy(-10)
                    scheduleControlsHide()
                } label: {
                    Image(systemName: "gobackward.10")
                        .font(.system(size: 34, weight: .medium))
                }

                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    player.togglePlayback()
                    scheduleControlsHide()
                } label: {
                    Image(systemName: player.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .font(.system(size: 62))
                }

                Button {
                    player.seekBy(10)
                    scheduleControlsHide()
                } label: {
                    Image(systemName: "goforward.10")
                        .font(.system(size: 34, weight: .medium))
                }

                Button {
                    player.togglePictureInPicture()
                    scheduleControlsHide()
                } label: {
                    Image(systemName: player.isPiPActive ? "pip.exit" : "pip.enter")
                        .font(.system(size: 26, weight: .medium))
                }
                .disabled(!player.canPictureInPicture)
                .opacity(player.canPictureInPicture ? 1 : 0.35)
                .accessibilityLabel("Picture in Picture")
            }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 24)
        .padding(.top, 24)
        .padding(.bottom, 16)
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                colors: [.black.opacity(0.8), .black.opacity(0.35), .clear],
                startPoint: .bottom,
                endPoint: .top
            )
        )
    }

    // MARK: - Motion-pause card

    private var motionPausedCard: some View {
        VStack(spacing: 14) {
            Image(systemName: "car.fill")
                .font(.system(size: 54))
                .foregroundStyle(.white)
            Text("Car appears to be moving")
                .font(.title2.bold())
                .foregroundStyle(.white)
            Text("Playback was paused automatically.\nResume when you are safely parked.")
                .font(.body)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.85))
            Button {
                player.play()
                pausedByMotion = false
            } label: {
                Text("Resume anyway")
                    .font(.headline)
                    .foregroundStyle(.black)
                    .padding(.horizontal, 28)
                    .padding(.vertical, 12)
                    .background(Capsule().fill(.orange))
            }
            .padding(.top, 6)
        }
        .padding(36)
        .frame(maxWidth: 460)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.black.opacity(0.82)))
    }

    // MARK: - Controls auto-hide

    private func showControls() {
        hideTask?.cancel()
        withAnimation(.easeOut(duration: 0.2)) {
            controlsVisible = true
        }
        scheduleControlsHide()
    }

    private func hideControls() {
        withAnimation(.easeOut(duration: 0.25)) {
            controlsVisible = false
        }
    }

    private func scheduleControlsHide() {
        hideTask?.cancel()
        guard player.isPlaying else {
            controlsVisible = true
            return
        }
        hideTask = Task {
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            if !Task.isCancelled {
                withAnimation(.easeOut(duration: 0.35)) {
                    controlsVisible = false
                }
            }
        }
    }

    private func timeText(_ seconds: Double) -> String {
        let whole = Int(max(0, seconds))
        return String(format: "%d:%02d", whole / 60, whole % 60)
    }
}

// MARK: - Direct stream surface (video rendering only; controls are custom)

struct JohalAVPlayer: UIViewRepresentable {
    let player: AVPlayer

    func makeUIView(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.playsInline = true
        controller.videoGravity = .resizeAspect
        controller.showsPlaybackControls = false
        return controller
    }

    func updateUIView(_ uiView: AVPlayerViewController, context: Context) {
        if uiView.player !== player {
            uiView.player = player
        }
    }
}

// MARK: - YouTube surface (hosts the WKWebView owned by PlayerManager)

struct YouTubeSurface: UIViewRepresentable {
    let webView: WKWebView

    func makeUIView(context: Context) -> UIView {
        let container = UIView()
        container.backgroundColor = .black
        attach(container)
        return container
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        if webView.superview !== uiView {
            attach(uiView)
        }
    }

    private func attach(_ container: UIView) {
        webView.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: container.topAnchor),
            webView.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: container.trailingAnchor)
        ])
    }
}
