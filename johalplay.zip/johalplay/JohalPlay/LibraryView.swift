import SwiftUI

struct LibraryView: View {
    @EnvironmentObject private var library: StreamLibrary
    @EnvironmentObject private var player: PlayerManager

    @State private var showAddSheet = false
    @State private var renaming: StreamItem?
    @State private var query = ""

    private var filteredItems: [StreamItem] {
        guard !query.isEmpty else { return library.items }
        return library.items.filter {
            $0.name.localizedCaseInsensitiveContains(query)
                || $0.url.absoluteString.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        Group {
            if library.items.isEmpty {
                emptyState
            } else {
                streamList
            }
        }
        .navigationTitle("JohalPlay")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showAddSheet = true
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                }
                .accessibilityLabel("Add a video link")
            }
        }
        .searchable(text: $query, prompt: "Search your videos")
        .sheet(isPresented: $showAddSheet) {
            AddStreamView(
                onDismiss: { showAddSheet = false },
                onAdded: { item in
                    player.load(item, autoplay: true)
                }
            )
        }
        .sheet(item: $renaming) { item in
            RenameStreamView(item: item)
        }
    }

    // MARK: - Subviews

    private var streamList: some View {
        List {
            ForEach(filteredItems) { item in
                StreamRow(item: item)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        player.load(item, autoplay: true)
                    }
                    .swipeActions(edge: .leading) {
                        Button {
                            renaming = item
                        } label: {
                            Label("Rename", systemImage: "pencil")
                        }
                        .tint(.yellow)
                    }
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            library.remove(item)
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
            }
        }
        .listStyle(.insetGrouped)
        .overlay {
            if filteredItems.isEmpty {
                ContentUnavailableView(
                    "No matches",
                    systemImage: "magnifyingglass",
                    description: Text("Nothing in your list matches “\(query)”")
                )
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(Color.orange.opacity(0.12))
                    .frame(width: 96, height: 96)
                Image(systemName: "car.and.arrow.forward")
                    .font(.system(size: 40, weight: .medium))
                    .foregroundStyle(Color.orange)
            }
            Text("No videos yet")
                .font(.title3.bold())
            Text("Tap + and paste a link. YouTube videos and direct MP4/HLS streams both work — they play on this phone, mounted in your car.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 32)
            Button {
                showAddSheet = true
            } label: {
                Label("Add your first video", systemImage: "plus.circle.fill")
                    .font(.body.weight(.semibold))
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
            }
            .buttonStyle(.borderedProminent)
            .tint(.orange)
            .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Row

struct StreamRow: View {
    let item: StreamItem

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: item.kind == .youtube ? "play.rectangle.fill" : "video.fill")
                .font(.title2)
                .foregroundStyle(item.kind == .youtube ? .red : .blue)
                .frame(width: 44, height: 44)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(item.kind == .youtube ? Color.red.opacity(0.15) : Color.blue.opacity(0.15))
                )

            VStack(alignment: .leading, spacing: 5) {
                Text(item.name)
                    .font(.body.weight(.semibold))
                    .lineLimit(2)

                HStack(spacing: 8) {
                    if let resumeAt = item.resumePosition {
                        Text("Resume \(timeText(resumeAt))")
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.orange)
                        progressBar
                    } else {
                        Text(hostText)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.tertiary)
        }
        .padding(.vertical, 4)
    }

    private var progressBar: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.12))
                Capsule()
                    .fill(Color.orange)
                    .frame(width: max(8, geo.size.width * progressValue))
            }
        }
        .frame(width: 56, height: 4)
    }

    private var progressValue: Double {
        guard let duration = item.duration, duration > 0,
              let position = item.lastPosition else { return 0 }
        return min(1, max(0, position / duration))
    }

    private var hostText: String {
        if let host = item.url.host {
            return host.replacingOccurrences(of: "www.", with: "")
        }
        return item.url.absoluteString
    }

    private func timeText(_ seconds: Double) -> String {
        let whole = Int(max(0, seconds))
        return String(format: "%d:%02d", whole / 60, whole % 60)
    }
}

// MARK: - Add sheet

struct AddStreamView: View {
    @EnvironmentObject private var library: StreamLibrary
    var onDismiss: () -> Void
    var onAdded: (StreamItem) -> Void

    @State private var urlString: String = ""
    @State private var isAdding = false
    @State private var localError: String?
    @FocusState private var urlFieldFocused: Bool

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                TextField("Paste a video link", text: $urlString, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                    .focused($urlFieldFocused)
                    .font(.body.monospaced())

                if let localError {
                    Text(localError)
                        .font(.footnote)
                        .foregroundStyle(.red)
                }

                HStack(spacing: 8) {
                    FeatureChip(icon: "play.rectangle.fill", color: .red, text: "YouTube links")
                    FeatureChip(icon: "video.fill", color: .blue, text: "MP4 / HLS links")
                }

                Text("Tip: resume-where-you-left-off and auto-next are built in. Links you add stay in your list.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if isAdding {
                    HStack(spacing: 10) {
                        ProgressView()
                        Text("Adding…")
                    }
                    .frame(maxWidth: .infinity)
                }

                Spacer()
            }
            .padding()
            .navigationTitle("Add video")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { onDismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isAdding ? "Adding…" : "Add") {
                        add()
                    }
                    .disabled(urlString.trimmingCharacters(in: .whitespaces).isEmpty || isAdding)
                }
            }
            .onAppear {
                urlFieldFocused = true
            }
        }
    }

    private func add() {
        isAdding = true
        localError = nil
        urlFieldFocused = false
        let input = urlString
        Task {
            if let item = await library.add(urlString: input) {
                isAdding = false
                onDismiss()
                onAdded(item)
            } else {
                isAdding = false
                localError = library.addErrorMessage ?? "Could not add that link."
            }
        }
    }
}

struct FeatureChip: View {
    let icon: String
    let color: Color
    let text: String

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
            Text(text)
                .font(.caption.weight(.medium))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(Capsule().fill(color.opacity(0.14)))
        .foregroundStyle(color)
    }
}

// MARK: - Rename sheet

struct RenameStreamView: View {
    @EnvironmentObject private var library: StreamLibrary
    @Environment(\.dismiss) private var dismiss
    let item: StreamItem
    @State private var name: String

    init(item: StreamItem) {
        self.item = item
        _name = State(initialValue: item.name)
    }

    var body: some View {
        NavigationStack {
            TextField("Name", text: $name)
                .textFieldStyle(.roundedBorder)
                .padding()
                .navigationTitle("Rename")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { dismiss() }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") {
                            library.rename(item, to: name)
                            dismiss()
                        }
                        .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                }
        }
    }
}
